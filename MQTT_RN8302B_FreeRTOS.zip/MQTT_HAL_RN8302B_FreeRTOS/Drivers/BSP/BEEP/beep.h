#ifndef _BEEP_H
#define _BEEP_H
#include "sys.h"


/******************************************************************************************/
/* ���� ���� */

#define BEEP_GPIO_PORT                  GPIOC
#define BEEP_GPIO_PIN                   GPIO_PIN_13
#define BEEP_GPIO_CLK_ENABLE()          do{ __HAL_RCC_GPIOC_CLK_ENABLE(); }while(0)             /* PC��ʱ��ʹ�� */


/******************************************************************************************/
/* BEEF�˿ڶ��� */
#define BEEP(x)   do{ x ? \
                      HAL_GPIO_WritePin(BEEP_GPIO_PORT, BEEP_GPIO_PIN, GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(BEEP_GPIO_PORT, BEEP_GPIO_PIN, GPIO_PIN_RESET); \
                  }while(0)    

				  
/* BEEFȡ������ */
#define BEEP_TOGGLE()   do{ HAL_GPIO_TogglePin(BEEP_GPIO_PORT, BEEP_GPIO_PIN); }while(0)        /* ��תBEEF */

/******************************************************************************************/
/* �ⲿ�ӿں���*/
void beep_init(void);                                                                            /* ��ʼ�� */

#endif
